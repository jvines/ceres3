# Fast rotator analysis utilities.
